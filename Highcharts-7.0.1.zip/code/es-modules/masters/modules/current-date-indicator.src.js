/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * CurrentDateIndicator
 *
 * (c) 2010-2018 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/CurrentDateIndicator.js';
